public interface Figura {

    public double area();
    public double perimetre();
}
